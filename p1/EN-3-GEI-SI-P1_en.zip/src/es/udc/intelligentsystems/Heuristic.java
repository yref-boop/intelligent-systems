package es.udc.intelligentsystems;

public abstract class Heuristic {
    public abstract float evaluate(State e);
}
